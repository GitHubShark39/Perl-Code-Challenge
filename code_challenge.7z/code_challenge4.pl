#!/usr/bin/perl

$id = 007;             			# An integer assignment
$datestring = localtime();    		# Date String
$firstname = "Royal";   		# A string 
$lastname = "Jackson";   		# A string 
$location = Florida;     		# A String

print "Created = $datestring\n";

print "\n";
print "Employee\n";
print "EmployeeType\n";
print "ID = $id\n";
print "FirstName = $firstname\n";
print "ID = $id\n";


print "\n";
print "LastName = $lastname\n";

print "ID = $id\n";
print "\n";

print "\n";
print "Location = $location\n";



print "\n";
print "Local date and time $datestring\n";


