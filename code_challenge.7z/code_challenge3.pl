#!/usr/bin/perl

$id = 007;             			# An integer assignment
$datestring = localtime();    		# Date String
$firstname = "Royal";   		# A string 
$lastname = "Jackson";   		# A string 
$location = Florida;     		# A String

print "ID = $id\n";
print "\n";
print "Created = $datestring\n";

print "\n";
print "Employee\n";
print "ID = $id\n";
print "FirstName = $firstname\n";

print "\n";
print "EmployeeType\n";
print "ID = $id\n";

print "\n";
print "LastName = $lastname\n";

print "\n";
print "location = $location\n";


print "\n";
print "Local date and time $datestring\n";
